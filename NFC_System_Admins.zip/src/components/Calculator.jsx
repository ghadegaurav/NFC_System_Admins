import '../styles/Calculator.css'

export default function Calculator() {
    return <>
        <div className='calc'>
            <h1>Calculator page</h1>
        </div>
    </>
}