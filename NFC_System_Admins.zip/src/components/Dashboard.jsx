export default (Dashboard) => {
    return <>
    <h1>Dashboard</h1></>
}