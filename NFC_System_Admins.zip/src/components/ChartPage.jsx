import {
    Chart as ChartJS,
    BarElement,
    CategoryScale,
    LinearScale,
    Tooltip,
    Legend
} from 'chart.js'
import { useState } from 'react';

import {Bar} from 'react-chartjs-2'
ChartJS.register(
    BarElement,
    CategoryScale,
    LinearScale,
    Tooltip,
    Legend
);
function ChartPage(){
    const [dataNums, setDataNums] = useState([3, 6, 9])
    const clicked = () => setDataNums([9, 6, 9])
    const data = {
        labels: ["Mon", "Tue", "Wed"], 
        datasets: [
      {
        label: "369",
        data: dataNums,
        borderColor: "black",
        borderWidth: 2
      }
    ]
    }
    return (
        <div className='charts'>
            <Bar data={data}></Bar>
            <button onClick={clicked}>change</button>
        </div>
    )
}

export default ChartPage