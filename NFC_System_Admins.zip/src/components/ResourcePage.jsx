import '../styles/Resource.css'

export default (ResourcePage) => {
    return(
        <>
           <div className="rsrc">
            <h1>Resource page</h1>
            </div> 
        </>
    )
}